package com.flightapp.booking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.flightapp.booking.model.Admin;
import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.model.NewFlightDetails;


@Repository
public interface FlightBookingRepositoryJpa extends JpaRepository<UserDetails, Integer>{
	
	/*
	 * public String storeNameinDb(String name) { System.out.println("hello" +
	 * name); return "hello" + name ; }
	 */
	
	 public List<UserDetails> findAll();
	 public UserDetails save(UserDetails ud);
	 
	@Query("from Admin u where u.email = :email and u.password = :pwd" )
	List<Admin> findAllDetails(@Param("email") String email,@Param("pwd") String pwd);
	
	NewFlightDetails save(NewFlightDetails nfd);
	NewFlightDetails findById(int fNum);
	 
}
