package com.flightapp.booking.model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class NewFlightDetails {

	public NewFlightDetails(int flightNum, String airlineName, String departute, String arrival,
			LocalDateTime departureDateTime, LocalDateTime arrivalDteTime, String meals, Double price, int maxSeats,
			String status) {
		
		this.flightNum = flightNum;
		this.airlineName = airlineName;
		this.departute = departute;
		this.arrival = arrival;
		this.departureDateTime = departureDateTime;
		this.arrivalDteTime = arrivalDteTime;
		this.meals = meals;
		this.price = price;
		this.maxSeats = maxSeats;
		this.status = status;
	}
	public NewFlightDetails() {
		
	}
	public int getFlightNum() {
		return flightNum;
	}
	public void setFlightNum(int flightNum) {
		this.flightNum = flightNum;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	public String getDepartute() {
		return departute;
	}
	public void setDepartute(String departute) {
		this.departute = departute;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public LocalDateTime getDepartureDateTime() {
		return departureDateTime;
	}
	public void setDepartureDateTime(LocalDateTime departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
	public LocalDateTime getArrivalDteTime() {
		return arrivalDteTime;
	}
	public void setArrivalDteTime(LocalDateTime arrivalDteTime) {
		this.arrivalDteTime = arrivalDteTime;
	}
	public String getMeals() {
		return meals;
	}
	public void setMeals(String meals) {
		this.meals = meals;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public int getMaxSeats() {
		return maxSeats;
	}
	public void setMaxSeats(int maxSeats) {
		this.maxSeats = maxSeats;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Id    
	private int flightNum;
	private String airlineName;
	private String departute;
	private String arrival;
	private LocalDateTime departureDateTime;
	private LocalDateTime arrivalDteTime;
	private String meals;
	private Double price;
	private int maxSeats;
	private String status;
	
	
}
