package com.flightapp.booking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.booking.model.Admin;
import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.model.NewFlightDetails;
import com.flightapp.booking.repository.FlightBookingRepositoryJpa;

@Service
public class FlightServiceJpa {
	@Autowired
	FlightBookingRepositoryJpa repo1;
	
	public List<UserDetails> findAllDetails(){
		return repo1.findAll();
		
	}
	public UserDetails storeName(UserDetails ud){
		return repo1.save(ud);
		
	}
	public String findByIdDetails(String email,String pwd) {
	//	List<Admin> ad=new ArrayList<>();
		List<Admin> a  =repo1.findAllDetails(email,pwd);
		//Admin ud=//
		System.out.println(a.get(0).getEmail());
		String ad =a.get(0).getEmail(); 
		String pd =a.get(0).getPassword();
		
		if(email.equalsIgnoreCase(ad) && pwd.equalsIgnoreCase(pd)) {
			System.out.println("admin login success");
			return "successful";
		}
		return "successful";
	}
	public NewFlightDetails saveDetails(NewFlightDetails nfd){
		return repo1.save(nfd);
		
	}
	public NewFlightDetails findDetailsById(int fNum){
		return repo1.findById(fNum);
	}

}
