package com.flightapp.booking.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.model.NewFlightDetails;
import com.flightapp.booking.service.FlightBookingService;
import com.flightapp.booking.service.FlightServiceJpa;

@RestController
@RequestMapping("/v1/api")
public class FlightBookingController {
	
	@Autowired
	FlightBookingService service;
	@Autowired
	FlightServiceJpa service1;
	
	
	/*
	 * @PostMapping("/{id}/{name}/{email}") public void name(@PathVariable("id") int
	 * id,@PathVariable("name") String name,
	 * 
	 * @PathVariable("email") String email) { UserDetails ud = new UserDetails( id,
	 * name, email); service1.storeName(ud); }
	 * 
	 * @GetMapping("/all") public List<UserDetails> findall(){ return
	 * service1.findAllDetails(); }
	 */
	 	@GetMapping("/{email}/{password}")
		public String snameLogin(@PathVariable("email") String email,
				@PathVariable("password") String password) {
	 							
		 return service1.findByIdDetails(email,password);	
			
		}
		
		@PostMapping("/airlines")
		public String addingFlightDetails(@RequestBody NewFlightDetails nfd) {
			 service1.saveDetails(nfd);
			 return "sucessfull";
			
		}
		@GetMapping("/displayFlightDetails")
		public ResponseEntity<List<NewFlightDetails>> displayFlightDetails(/* @PathVariable("flightNum") int fNum */) {
			//List<NewFlightDetails> nf  = new ArrayList<>();
			//NewFlightDetails nfd1 =service1.findDetailsById(fNum);
			//System.out.println("Sample"+nfd1.getAirlineName());
			List<NewFlightDetails> nf  = service1.findAllFlightDetails();
			return new ResponseEntity<>(nf, HttpStatus.OK);
		}
		@PostMapping("/changeStatus/{flightNum}/{flightStatus}")
		public String updateFlightDetails(@PathVariable("flightNum") int fnum, @PathVariable("flightStatus") String status) {
			 service1.updateDetails(fnum,status);
			 return "sucessfull";
			
		}
		 
}
