package com.flightapp.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.service.FlightBookingService;

@RestController
public class FlightBookingController {
	
	@Autowired
	FlightBookingService service;
	
	/*
	 * @PostMapping("/{name}") public void name(@PathVariable String name) {
	 * service.storeName(name); }
	 */
	@PostMapping("/{id}/{name}/{email}")
	public void name(@PathVariable("id") int id,@PathVariable("name") String name,
			@PathVariable("email") String email) {
		UserDetails ud = new UserDetails( id,  name,  email);
		 service.storeName(ud);  
	}

}
