package com.flightapp.booking.repository;

import org.springframework.data.repository.CrudRepository;

import com.flightapp.booking.model.UserDetails;

public interface FlightBookingRepository extends CrudRepository<UserDetails,String> {

}
