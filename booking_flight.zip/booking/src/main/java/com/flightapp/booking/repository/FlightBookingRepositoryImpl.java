package com.flightapp.booking.repository;

import org.springframework.stereotype.Repository;

@Repository
public class FlightBookingRepositoryImpl {
	
	public String storeNameinDb(String name) {
		System.out.println("hello" + name);
		return "hello" + name ;
	}

}
