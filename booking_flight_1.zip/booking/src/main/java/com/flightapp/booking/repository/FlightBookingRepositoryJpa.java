package com.flightapp.booking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.flightapp.booking.model.UserDetails;

@Repository
public interface FlightBookingRepositoryJpa extends JpaRepository<UserDetails, Integer>{
	
	/*
	 * public String storeNameinDb(String name) { System.out.println("hello" +
	 * name); return "hello" + name ; }
	 */
	
	 public List<UserDetails> findAll();
	 public UserDetails save(UserDetails ud);
	 
}
