package com.flightapp.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.repository.FlightBookingRepositoryJpa;

@Service
public class FlightServiceJpa {
	@Autowired
	FlightBookingRepositoryJpa repo1;
	
	public List<UserDetails> findAllDetails(){
		return repo1.findAll();
		
	}
	public UserDetails storeName(UserDetails ud){
		return repo1.save(ud);
		
	}

}
