package com.flightapp.booking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.booking.model.Admin;
import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.repository.FlightBookingRepositoryJpa;

@Service
public class FlightServiceJpa {
	@Autowired
	FlightBookingRepositoryJpa repo1;
	
	public List<UserDetails> findAllDetails(){
		return repo1.findAll();
		
	}
	public UserDetails storeName(UserDetails ud){
		return repo1.save(ud);
		
	}
	public String findByIdDetails(String email,String pwd) {
	//	List<Admin> ad=new ArrayList<>();
		Admin a  =repo1.findAllDetails(email,pwd);
		//Admin ud=//
		String ad =repo1.findAllDetails(email,pwd).getEmail().toString(); 
		String pd =repo1.findAllDetails(email,pwd).getPassword().toString();
		
		if(email.equalsIgnoreCase(ad) && pwd.equalsIgnoreCase(pd)) {
			System.out.println("admin login success");
			return "successful";
		}
		return "successful";
	}

}
