package com.flightapp.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightapp.booking.model.UserDetails;
import com.flightapp.booking.service.FlightBookingService;
import com.flightapp.booking.service.FlightServiceJpa;

@RestController
public class FlightBookingController {
	
	@Autowired
	FlightBookingService service;
	@Autowired
	FlightServiceJpa service1;
	
	/*
	 * @PostMapping("/{name}") public void name(@PathVariable String name) {
	 * service.storeName(name); }
	 */
	@PostMapping("/{id}/{name}/{email}")
	public void name(@PathVariable("id") int id,@PathVariable("name") String name,
			@PathVariable("email") String email) {
		UserDetails ud = new UserDetails( id,  name,  email);
		 service1.storeName(ud);  
	}
		 @GetMapping("/all")
		 public List<UserDetails> findall(){
			 return service1.findAllDetails();
		 }
	 	@GetMapping("/{email}/{password}")
		public void snameLogin(@PathVariable("email") String email,
				@PathVariable("password") String password) {
	 		//Admin ud = new UserDetails( id,  name,  email);					
		 service1.findByIdDetails(email,password);	
			
		}
}
