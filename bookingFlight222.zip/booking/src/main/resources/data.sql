DROP TABLE IF EXISTS admin;

CREATE TABLE admin (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  name VARCHAR(250) NOT NULL,
  uname VARCHAR(250) NOT NULL,
  password VARCHAR(250) NOT NULL
);

INSERT INTO ADMIN (id, name) VALUES
  (1,'abc');
  
  INSERT INTO USER_DETAILS (id, email,name) VALUES
  (1,'abc@hnju.com',name);